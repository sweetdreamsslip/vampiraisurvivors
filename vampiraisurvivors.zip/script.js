var canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");
var lastUpdateTime;

var WIDTH = window.innerWidth-20;
var HEIGHT = window.innerHeight-20;
canvas.width = WIDTH;
canvas.height = HEIGHT;


var mouse = {
    x: 0,
    y: 0,
    mouseDown: false,
};

var red_ball = {
    x: 100,
    y: 100,
    radius: 10,
    render: function(ctx){
        ctx.save();
        ctx.fillStyle = "red";
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, 2 * Math.PI);
        ctx.fill();
        ctx.restore();
    },
    update: function(dt){
        this.x = mouse.x;
        this.y = mouse.y;
    }
}; 
var collision_ball = {
    x: 200,
    y: 200,
    radius: 50,
    collision: false,
    render: function(ctx){
        ctx.save();
        if(this.collision){
            ctx.fillStyle = "green";
        }else{
            ctx.fillStyle = "blue";
        }
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, 2 * Math.PI);
        ctx.fill();
        ctx.restore();
    },
    update: function(dt){

    }
};

canvas.addEventListener("mousemove", function(e) {
    var rect = canvas.getBoundingClientRect();
    mouse.x = e.clientX - rect.left;
    mouse.y = e.clientY - rect.top;
});
canvas.addEventListener("mousedown", function(e) {
    mouse.mouseDown = true;
});

canvas.addEventListener("mouseup", function(e) {
    mouse.mouseDown = false;
});






function update(dt) {
    red_ball.update(dt);
    collision_ball.update(dt);
    collision_ball.collision = aabbCircleCollision(red_ball, collision_ball);
    if(mouse.mouseDown && collision_ball.collision){
        collision_ball.x = randomIntBetween(0, WIDTH);
        collision_ball.y = randomIntBetween(0, HEIGHT);
    }
}

function render() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    collision_ball.render(ctx);
    red_ball.render(ctx);
    ctx.fillStyle = "red";
    ctx.font = "24px Arial";
    ctx.fillText("Mouse: x=" + mouse.x + " y=" + mouse.y, 20, 40);
}

function run() {
    var now = performance.now();
    var dt = (now - lastUpdateTime); // dt in seconds
    lastUpdateTime = now;
    update(dt);
    render();
    requestAnimationFrame(run);
}

lastUpdateTime = performance.now();
run();
